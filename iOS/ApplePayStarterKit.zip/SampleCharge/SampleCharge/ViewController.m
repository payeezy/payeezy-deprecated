//
//  ViewController.m
//  SampleCharge
//
//  Created by First Data Corporation on 8/28/14.
//  Copyright (c) 2014 First Data Corporation. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

#import <InAppSDK/InAppSDK.h>

@implementation ViewController

- (IBAction)payClicked:(id)sender {

    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];

    NSArray *supportedNetworks = @[
                                   FDPaymentNetworkVisa,
                                   FDPaymentNetworkMasterCard,
                                   FDPaymentNetworkAmericanExpress
                                   ];
    
    // Does this device support In-App payments?
    if ([FDInAppPaymentProcessor canMakePayments])
    {
        // Is a card registered on the device for one of the merchant's suported card networks?
        if ([FDInAppPaymentProcessor canMakePaymentsUsingNetworks:supportedNetworks])
        {
            // Populate the payment request
            FDPaymentRequest *pmtRqst = [[FDPaymentRequest alloc] init];
            pmtRqst.merchantIdentifier = kOsloMerchantId;
            pmtRqst.supportedNetworks = supportedNetworks;
            pmtRqst.countryCode = @"US";
            pmtRqst.currencyCode = @"USD";
            pmtRqst.merchantCapabilities = FDMerchantCapability3DS | FDMerchantCapability3EMV;
            pmtRqst.requiredShippingAddressFields = FDAddressFieldNone;
            
            // Set the payment type
            appDelegate.fdPaymentProcessor.paymentMode = (self.segPaymentType.selectedSegmentIndex==0 ? FDPreAuthorization : FDPurchase);
            
            FDShippingMethod *shipping = [[FDShippingMethod alloc] init];
            shipping.identifier = @"Two Day Shipping";
            shipping.detail = @"Two day shipping to the Continental US";
            pmtRqst.shippingMethods = @[shipping];
            
            // Create a sample order
            FDPaymentSummaryItem *item1 = [[FDPaymentSummaryItem alloc] init];
            item1.label = @"Large Shoes";
            item1.amount = [NSDecimalNumber decimalNumberWithString:self.txtAmount.text];
            
            // Total line
            FDPaymentSummaryItem *item2 = [[FDPaymentSummaryItem alloc] init];
            item2.label = @"FD Test Merchant1";
            item2.amount = [NSDecimalNumber decimalNumberWithString:self.txtAmount.text];
            NSArray *itemArray = [NSArray arrayWithObjects: item1, item2, nil];
            pmtRqst.paymentSummaryItems = itemArray;
            
            // Send a sample application data payload
            NSString *appDataString = @"RefCode:12345; TxID:34234089240982304823094823432";
            pmtRqst.applicationData = [appDataString dataUsingEncoding:NSUTF8StringEncoding];
            
            // Present FD authorization view controller
            [appDelegate.fdPaymentProcessor presentPaymentAuthorizationViewControllerWithPaymentRequest:pmtRqst
                                                                                   presentingController:self
                                                                                               delegate:self];
            
            // Delegate methods are driving from here...
        }
        else
        {
            NSLog(@"Ability to make payments of merchant-supported network types was rejected by FD SDK");
        }
    }
    else
    {
        NSLog(@"Ability for device to make payments was rejected by FD SDK");
    }
}


#pragma mark - FDPaymentAuthorizationViewControllerDelegate

- (void)paymentAuthorizationViewController:(UIViewController *)controller
                       didAuthorizePayment:(FDPaymentResponse *)paymentResponse
{
    
    NSString *authStatusMessage = nil;
    
    if (paymentResponse.validationStatus != FDPaymentValidationStatusSuccess)
    {
        authStatusMessage = @"Transaction Validation or communication failure. Please try again.";
    }
    else if (paymentResponse.authStatus == FDPaymentAuthorizationStatusFailure)
    {
        authStatusMessage = [NSString stringWithFormat:@"Transaction was validated but authorization failed with reason: %@", paymentResponse.transStatusMessage];
        
    }
    else if (paymentResponse.authStatus == FDPaymentAuthorizationStatusSuccess)
    {
        authStatusMessage = [NSString stringWithFormat:@"Transaction Successful\rType:%@\rTransaction ID:%@\rTransaction Tag:%@",
                             paymentResponse.transactionType,
                             paymentResponse.transactionID,
                             paymentResponse.transactionTag];
    }
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"First Data Payment Authorization"
                                                    message:authStatusMessage delegate:self
                                          cancelButtonTitle:@"Dismiss"
                                          otherButtonTitles:nil];
    [alert show];
    
    // App can send order to the merchant's back-end server now
}

- (void)paymentAuthorizationViewControllerDidFinish:(UIViewController *)controller
{
    // Nothing to do here - the SDK handles all cleanup
    
    NSLog(@"ViewController:paymentAuthorizationViewControllerDidFinish invoked");
}

- (void)paymentAuthorizationViewController:(UIViewController *)controller
                   didSelectShippingMethod:(FDShippingMethod *)shippingMethod
{
    // The customer has asked the merchant to use a specific shipping method.  We need to update the amount.
    // We can also get here if the customer said the heck with it and canceled.
    
    NSLog(@"ViewController:didSelectShippingMethod invoked");
}

- (void)paymentAuthorizationViewController:(UIViewController *)controller
                  didSelectShippingAddress:(ABRecordRef)address
{
    // The customer is telling the merchant shipping address information.  We need to update the amount.
    // We can also get here if the customer said the heck with it and canceled.
    
    NSLog(@"ViewController:didSelectShippingAddress invoked");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
