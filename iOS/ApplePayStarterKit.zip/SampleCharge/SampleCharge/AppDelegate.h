//
//  AppDelegate.h
//  SampleCharge
//
//  Created by First Data Corporation on 8/28/14.
//  Copyright (c) 2014 First Data Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FDInAppPaymentProcessor;

#define kApiKey             @"y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a"
#define kApiSecret          @"y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a"
#define kMerchantToken      @"fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6"
#define kOsloMerchantId     @"mock-1"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) FDInAppPaymentProcessor *fdPaymentProcessor;


@end

