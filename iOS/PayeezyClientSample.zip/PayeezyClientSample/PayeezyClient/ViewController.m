//
//  ViewController.m
//  PayeezyClient
//
//  Created by First Data Corporation on 8/28/14.
//  Copyright (c) 2014 First Data Corporation. All rights reserved.
//

#import "ViewController.h"
#import <PayeezyClient/PayeezyClient.h>

// Credentials for shared test account in CERT environment
// Does NOT process actual transactions
#define KApiKey     @"y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a"
#define KApiSecret  @"86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7"
#define KToken      @"fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6"
#define KURL        @"https://api-cert.payeezy.com/v1/transactions"

@implementation ViewController
            
- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewDidAppear:(BOOL)animated{
    
    _amountEntered.text = @"";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)authorizeTransaction:(id)sender {
    
    NSDecimalNumber* valueEntered = [NSDecimalNumber decimalNumberWithString:_amountEntered.text];
    
    if (![valueEntered isEqualToNumber:[NSDecimalNumber notANumber]]) {
        
        NSString *amount = [[NSString stringWithFormat:@"%@",valueEntered] stringByReplacingOccurrencesOfString:@"." withString:@""];

        // Test credit card info
        NSDictionary* credit_card = @{
                                      @"type":@"visa",
                                      @"cardholder_name":@"Unknown",
                                      @"card_number":@"4788250000028291",
                                      @"exp_date":@"1014",
                                      @"cvv":@"123"
                                      };
        PayeezyClient* myClient = [[PayeezyClient alloc]initWithApiKey:KApiKey apiSecret:KApiSecret merchantToken:KToken];
        
        myClient.url = KURL;
        
        [myClient submitAuthorizeTransactionWithCreditCardDetails:credit_card[@"type"] cardHolderName:credit_card[@"cardholder_name"] cardNumber:credit_card[@"card_number"] cardExpirymMonthAndYear:credit_card[@"exp_date"] cardCVV:credit_card[@"cvv"] currencyCode:@"USD" totalAmount:amount merchantRefForProcessing:@"Test Authorization Transaction - PayeezyClient"

                          completion:^(NSDictionary *dict, NSError *error) {
    
                              NSString *authStatusMessage = nil;
                              
                              if (error == nil)
                              {
                                  authStatusMessage = [NSString stringWithFormat:@"Transaction Successful\rType:%@\rTransaction ID:%@\rTransaction Tag:%@",
                                                        [dict objectForKey:@"transaction_type"],
                                                        [dict objectForKey:@"transaction_id"],
                                                         [dict objectForKey:@"transaction_tag"]];
                              }
                              else
                              {
                                  authStatusMessage = [NSString stringWithFormat:@"Error was encountered processing transaction: %@", error.debugDescription];
                              }

                              UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"First Data Payment Authorization"
                                                                              message:authStatusMessage delegate:self
                                                                    cancelButtonTitle:@"Dismiss"
                                                                    otherButtonTitles:nil];
                              [alert show];
                          }];
    }
}
@end
